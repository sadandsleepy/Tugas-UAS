<?php 

namespace App\Controllers;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Models\MahasiswaModel;

class Mahasiswa extends ResourceController
{
    use ResponseTrait;

    public $conn;

    public function __construct(){
            $this->conn = \Config\Database::connect();
    }

    public function index(){
        $model = new MahasiswaModel();
        $data = $model->orderBy('id', 'ASC')->findAll();
        return $this->respond($data);
    }

    public function show($id = null){
        $model = new MahasiswaModel();
        $data = $model->where('id', $id)->first();
        if($data){
            return $this->respond($data);
        }else{
            return $this->failNotFound('data does not exist.');
        }
    }

    // create
    public function create() {
        $model = new MahasiswaModel();
        $data = [
            'nama'  => $this->request->getVar('nama'),
            'jurusan'  => $this->request->getVar('jurusan'),
            'nim' => $this->request->getVar('nim'),
            'jenis_kelamin'  => $this->request->getVar('jenis_kelamin'),
            'alamat' => $this->request->getVar('alamat'),
            'picture' => $this->request->getVar('picture')
        ];
        
        $model->insert($data);
        $response = [
          'status'   => 201,
          'error'    => null,
          'messages' => 'Data created'
      ];
      return $this->respondCreated($response);
    }

    // upload image
    public function upload(){
        $file = $this->request->getFile('file');
		if(! $file->isValid())
		return $this->fail($file->getErrorString());
		$file->move('imgs');

        // $image = $_FILES['image']['name'];
        // $imagePath = "imgs/".$image;
        // move_uploaded_file($_FILES['image']['tmp_name'],$imagePath);
    }


    // update
    public function update($id = null){
        $model = $this->conn->table('mahasiswa');
        // $id = $this->request->getVar('id');
        $data = [
            'nama'  => $this->request->getVar('nama'),
            'jurusan'  => $this->request->getVar('jurusan'),
            'nim' => $this->request->getVar('nim'),
            'jenis_kelamin'  => $this->request->getVar('jenis_kelamin'),
            'alamat' => $this->request->getVar('alamat'),
            'picture' => $this->request->getVar('picture')
        ];
        $model->where('id', $id);
        $model->update($data);
        $response = [
          'status'   => 200,
          'error'    => null,
          'messages' => 'Data updated'
      ];
      return $this->respond($response);
    }

    // public function putupdate(){
    //     $id = $this->request->getVar('id');
    //     $db = $this->conn->table('user');
    //     $model = new MahasiswaModel();
    //     $data = [
    //         'nama'  => $this->request->getVar('nama'),
    //         'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
    //         'jenis_kelamin'  => $this->request->getVar('jenis_kelamin'),
    //         'alamat' => $this->request->getVar('alamat')
    //     ];
    //     $db->where('id', $id);
    //     $db->update($data);

    // }

    public function delete($id = null){
        $model = new MahasiswaModel();
        $data = $model->where('id', $id)->delete($id);
        if($data){
            $model->delete($id);
            $response = [
                'status'   => 200,
                'error'    => null,
                'messages' => [
                    'success' => 'data successfully deleted'
                ]
            ];
            return $this->respondDeleted($response);
        }else{
            return $this->failNotFound('No data found');
        }
    }
}
